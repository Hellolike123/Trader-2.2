# Install This Skill Package

This zip file IS a Hermes skill package.

To install, run these commands (find the zip path first):

```bash
ZIP_PATH=$(find ~ -maxdepth 4 -name 't0-trader.zip' 2>/dev/null | head -1)
mkdir -p ~/.hermes/skills/t0-trader
unzip -q "$ZIP_PATH" -d ~/.hermes/skills/t0-trader/
```

Alternatively, install locally if you have repo access:

```bash
python3 02-共享模块-shared/scripts/install_skill.py --hermes
```
