# Install Guide

This zip IS a Hermes skill package. Install it first before running:

```bash
mkdir -p ~/.hermes/skills/trader-tracking
unzip -q <zip-path> -d ~/.hermes/skills/trader-tracking/
```

Or install from the combined trader-all-skill.zip:

```bash
unzip -q trader-all-skill.zip -d ~/.hermes/skills/
```

---

# Hermes Contract

This package is a script-output skill.

Hermes must run one of:

```bash
python3 scripts/final_tracker.py
python3 scripts/final_tracker.py --check
python3 scripts/final_tracker.py --stock <股票名或代码>
python3 scripts/final_tracker.py --days <天数>
```

Return stdout exactly. Do not summarize, restyle, translate, shorten, add analysis, or supplement panel. If the script fails, return only the command error.
