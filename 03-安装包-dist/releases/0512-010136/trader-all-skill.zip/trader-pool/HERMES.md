# Install Guide

This zip IS a Hermes skill package. Install it first before running:

```bash
mkdir -p ~/.hermes/skills/trader-tracking
unzip -q <zip-path> -d ~/.hermes/skills/trader-tracking/
```

Or install from the combined trader-all-skill.zip:

```bash
unzip -q trader-all-skill.zip -d ~/.hermes/skills/
```

---

# Hermes Contract

This package is a script-output skill.

Hermes must run:

```bash
python3 scripts/final_pool.py add --target <股票名或代码>
python3 scripts/final_pool.py plan
python3 scripts/final_pool.py review
python3 scripts/final_pool.py show
```

Return stdout exactly. Do not summarize, restyle, translate, shorten, add analysis, or add follow-up text. If the script fails, return only the command error.
