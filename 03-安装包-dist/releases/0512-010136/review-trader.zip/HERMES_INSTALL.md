# Install This Skill Package

This zip file IS a Hermes skill package.

To install, run these commands (find the zip path first):

```bash
ZIP_PATH=$(find ~ -maxdepth 4 -name 'review-trader.zip' 2>/dev/null | head -1)
mkdir -p ~/.hermes/skills/review-trader
unzip -q "$ZIP_PATH" -d ~/.hermes/skills/review-trader/
```

Alternatively, install locally if you have repo access:

```bash
python3 02-共享模块-shared/scripts/install_skill.py --hermes
```
