# Install Guide

This is a Hermes/agent skill package. To install:

\`\`\`bash
mkdir -p ~/.hermes/skills/trader-tracking
unzip -q /Users/like/Downloads/项目/Trader 2.1/03-安装包-dist/releases/0512-010039/trader-tracking.zip -d ~/.hermes/skills/trader-tracking/
\`\`\`

Or use the combined package:
\`\`\`bash
unzip -q /Users/like/Downloads/项目/Trader 2.1/03-安装包-dist/releases/0512-010039/trader-all-skill.zip -d ~/.hermes/skills/
\`\`\`
