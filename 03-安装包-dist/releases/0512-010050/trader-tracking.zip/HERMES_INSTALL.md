# Install Guide

This is a Hermes/agent skill package zip.

To install, run these exact commands:

```bash
mkdir -p ~/.hermes/skills/trader-tracking
unzip -q /path/to//Users/like/Downloads/项目/Trader 2.1/03-安装包-dist/releases/0512-010050/trader-tracking.zip -d ~/.hermes/skills/trader-tracking/
```

Or install from the combined package:

```bash
unzip -q /Users/like/Downloads/项目/Trader 2.1/03-安装包-dist/releases/0512-010050/trader-all-skill.zip -d ~/.hermes/skills/
```
